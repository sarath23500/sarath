package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Feedback;
import in.nareshit.raghu.repo.FeedbackRepository;
import in.nareshit.raghu.service.IFeedbackService;
@Service
public class FeedbackServiceImpl implements IFeedbackService {

	@Autowired
	private FeedbackRepository repo;
	
	public Integer saveFeedback(Feedback s2) {
		s2 = repo.save(s2);
		return s2.getId2();
	}

	public void updateFeedback(Feedback s2) {
		repo.save(s2);
	}

	public Optional<Feedback> getOneFeedback(Integer id2) {
		return repo.findById(id2);
	}

	public List<Feedback> getAllFeedbacks() {
		return repo.findAll();
	}

	public boolean isFeedbackExist(Integer id2) {
		return repo.existsById(id2);
	}

	
}
