package in.nareshit.raghu.controller;

import java.util.List;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Feedback;
import in.nareshit.raghu.service.IFeedbackService;
import in.nareshit.raghu.util.FeedbackUtil;

@RestController
@RequestMapping("/rest/feedback")
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackRestController {

	private Logger log = LoggerFactory.getLogger(FeedbackRestController.class);

	@Autowired
	private IFeedbackService service;
	@Autowired
	private FeedbackUtil util;

	/**
	 * 1. Read JSON(Student) and convert to Object Format
	 *    Store data in Database. Return one Message.
	 */
	@PostMapping("/save")
	public ResponseEntity<String> saveFeedback(
			@RequestBody Feedback feedback)
	{
		log.info("Entered into method with Feedback data to save");

		ResponseEntity<String> resp = null;
		try {

			log.info("About to call save Operation");

			Integer id2 = service.saveFeedback(feedback);
			log.debug("Feedback saved with id2 "+id2);

			String body = "Feedback '"+id2+"' created";

			resp =  new ResponseEntity<String>(
					body, 
					HttpStatus.CREATED); //201

			log.info("Sucess response constructed");
		} catch (Exception e) {
			log.error("Unable to save feedback : problem is :"+e.getMessage());
			resp =  new ResponseEntity<String>(
					"Unable to Create Feedback", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}

		log.info("About to Exist save method with Response");
		return resp;
	}

	/**
	 * 2. Fetch all rows from database using Service
	 *    Sort data using name, return as JSON, 
	 *    else String message no data found.
	 *    
	 */
	@GetMapping("/all")
	public ResponseEntity<?> getAllFeedbacks() {
		log.info("Entered into method to fetch Students data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch feedback service");
			List<Feedback> list = service.getAllFeedbacks();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
				list.sort((s1,s2)->s1.getName().compareTo(s2.getName()));
				/* JDK 1.8
				list = list.stream()
						.sorted((s1,s2)->s1.getName().compareTo(s2.getName()))
						.collect(Collectors.toList());
				 */
				resp = new ResponseEntity<List<Feedback>>(list, HttpStatus.OK);
			} else {
				log.info("No Feedback exist: size "+list.size());

				//Res = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Feedbacks Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch feedbacks : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch Feedbacks", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}


	/***
	 * 3. Get one student object based on ID (PathVariable). 
	 *   If Object exist then return Student object 
	 *   else provide message(String).
	 */
	@GetMapping("/one/{id2}")
	public ResponseEntity<?> getOneStudent(
			@PathVariable Integer id2
			) 
	{
		log.info("Entered into Get one Feedback method");
		ResponseEntity<?> resp = null;
		try {
			log.info("About to make service call to fetch one record");
			Optional<Feedback> opt =  service.getOneFeedback(id2);
			if(opt.isPresent()) {
				log.info("Feedback exist=>"+id2);
				resp = new ResponseEntity<Feedback>(opt.get(), HttpStatus.OK);
				//resp = ResponseEntity.ok(opt.get());
			} else {
				log.warn("Given Feedback id2 not exist=>"+id2);
				resp = new ResponseEntity<String>(
						"Feedback '"+id2+"' not exist", 
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("Unable to process request fetch " + e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to process feedback fetch", 
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return resp;
	}

}
