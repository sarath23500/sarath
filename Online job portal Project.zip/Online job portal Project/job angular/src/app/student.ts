export class Student {
    id: number;
    company:string;
    name: string;
    gender:string;
    date1: string;
    phone: string;
    email: string;
    quali:string;
    addr: string;
}
 