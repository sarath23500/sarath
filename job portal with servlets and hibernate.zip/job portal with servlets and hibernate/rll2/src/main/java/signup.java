
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import javax.servlet.annotation.*;
@WebServlet("/signup")
public class signup extends HttpServlet
{	public void doPost(HttpServletRequest req,HttpServletResponse res)
			throws ServletException,IOException
	{		try
		{	res.setContentType("text/html");
			PrintWriter pw=res.getWriter();
			String a=req.getParameter("t3");
			String b=req.getParameter("t1");
			String c=req.getParameter("t2");
			String d=req.getParameter("t5");
			String e=req.getParameter("t6");
			String f=req.getParameter("t7");
			Configuration cfg=new Configuration();
			SessionFactory sf=cfg.configure().buildSessionFactory();
			Session ss=sf.openSession();
			mypojo2 pojo=new mypojo2();
			pojo.setEmail(a);
			pojo.setFirstname(b);
			pojo.setLastname(c);
			pojo.setPassword(d);
			pojo.setPhonenumber(e);
			pojo.setAddress(f);
			Transaction tx=ss.beginTransaction();
			ss.save(pojo);
			tx.commit();
			ss.close();
			res.sendRedirect("signin.html");
		}
		catch(Exception ae)
		{		}	}}


