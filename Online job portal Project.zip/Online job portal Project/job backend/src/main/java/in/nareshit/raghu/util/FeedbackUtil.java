package in.nareshit.raghu.util;
import org.springframework.stereotype.Component;
import in.nareshit.raghu.model.Feedback;

@Component
public class FeedbackUtil  {

	public void mapToActualObject(Feedback actual, Feedback feedback) {
		if(feedback.getName()!=null)
			actual.setName(feedback.getName());
			actual.setEmail(feedback.getEmail());
		    actual.setMessage(feedback.getMessage());
	}

}
