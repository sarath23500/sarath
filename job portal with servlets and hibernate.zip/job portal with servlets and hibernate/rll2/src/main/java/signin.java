
import java.io.*;
import java.sql.*;
import java.util.Iterator;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.*;
import org.hibernate.*;
import org.hibernate.cfg.*;




import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/signin")
public class signin extends HttpServlet {
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		 try
		    {
		    Class.forName("oracle.jdbc.driver.OracleDriver");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		        PreparedStatement st=con.prepareStatement
		    ("select * from signup1 where email=? and password=?");
		    st.setString(1,a);
		    st.setString(2,b);
		    ResultSet rs=st.executeQuery();
		    while(rs.next())
		    {
		    	HttpSession session = req.getSession(true);
                session.setAttribute("user",a);
		    res.sendRedirect("index.html");
		    }
		    res.sendRedirect("signin.html");
		    
		            }
		    catch(Exception ae)
		    {
		        ae.printStackTrace();
		    }
		    
	}
}
		


