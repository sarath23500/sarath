
export class Feedback {
    id2: number;
    name: string;
    email: string;
    message: string;
   
}