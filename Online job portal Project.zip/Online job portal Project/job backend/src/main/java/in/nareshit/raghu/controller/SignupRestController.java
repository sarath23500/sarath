package in.nareshit.raghu.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Signup;
import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.service.ISignupService;

import in.nareshit.raghu.util.SignupUtil;
import in.nareshit.raghu.util.StudentUtil;

@RestController
@RequestMapping("/rest/signup")
@CrossOrigin(origins = "http://localhost:4200")
public class SignupRestController {

	private Logger log = LoggerFactory.getLogger(SignupRestController.class);

	@Autowired
	private ISignupService service;
	@Autowired
	private SignupUtil util;

	/**
	 * 1. Read JSON(Student) and convert to Object Format
	 *    Store data in Database. Return one Message.
	 */
	@PostMapping("/save")
	public ResponseEntity<String> saveSignup(
			@RequestBody Signup signup)
	{
		log.info("Entered into method with Student data to save");

		ResponseEntity<String> resp = null;
		try {

			log.info("About to call save Operation");

			Integer id1 = service.saveSignup(signup);
			log.debug("Student saved with id "+id1);

			String body = "Student '"+id1+"' created";

			resp =  new ResponseEntity<String>(
					body, 
					HttpStatus.CREATED); //201

			log.info("Sucess response constructed");
		} catch (Exception e) {
			log.error("Unable to save student : problem is :"+e.getMessage());
			resp =  new ResponseEntity<String>(
					"Unable to Create Student", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}

		log.info("About to Exist save method with Response");
		return resp;
	}
	




	/**
	 * 2. Fetch all rows from database using Service
	 *    Sort data using name, return as JSON, 
	 *    else String message no data found.
	 *    
	 */
@GetMapping("/one/{regid}")
public ResponseEntity<?> getOneSignup(
		@PathVariable Integer regid
		) 
{
	log.info("Entered into Get one Student method");
	ResponseEntity<?> resp = null;
	try {
		log.info("About to make service call to fetch one record");
		Optional<Signup> opt =  service.getOneSignup(regid);
		if(opt.isPresent()) {
			log.info("Student exist=>"+regid);
			resp = new ResponseEntity<Signup>(opt.get(), HttpStatus.OK);
			//resp = ResponseEntity.ok(opt.get());
		} else {
			log.warn("Given Student id not exist=>"+regid);
			resp = new ResponseEntity<String>(
					"Student '"+regid+"' not exist", 
					HttpStatus.BAD_REQUEST);
		}
	} catch (Exception e) {
		log.error("Unable to process request fetch " + e.getMessage());
		resp = new ResponseEntity<String>(
				"Unable to process student fetch", 
				HttpStatus.INTERNAL_SERVER_ERROR);
		e.printStackTrace();
	}

	return resp;
}

		

}